package id.cyberx.signal

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.telephony.*
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.net.InetAddress
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadScheduledExecutor()
    private lateinit var rootStatus: TextView
    private lateinit var mobileValue: TextView
    private lateinit var mobileDetails: TextView
    private lateinit var wifiValue: TextView
    private lateinit var wifiDetails: TextView
    private lateinit var pingValue: TextView
    private lateinit var pingDetails: TextView
    private lateinit var statusLog: TextView
    private lateinit var transLabel: TextView
    private lateinit var transparency: SeekBar
    private lateinit var panel: android.view.View
    private var wifiOn = false
    private var dataOn = false
    private var rootAvailable = false
    private var pingCount = 0
    private var pingTotal = 0L
    private var pingMin = Long.MAX_VALUE
    private var pingMax = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        bindViews()
        requestNeededPermissions()
        checkRoot()
        setupCustomization()
        findViewById<Button>(R.id.wifiToggle).setOnClickListener { toggleWifi() }
        findViewById<Button>(R.id.dataToggle).setOnClickListener { toggleMobileData() }
        findViewById<Button>(R.id.btToggle).setOnClickListener {
            startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        findViewById<Button>(R.id.locationToggle).setOnClickListener {
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }
        findViewById<Button>(R.id.allSettings).setOnClickListener {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
        }
        startMonitoring()
    }

    
private fun bindViews() {
    rootStatus = findViewById(R.id.rootStatus)
    mobileValue = findViewById(R.id.mobileValue)
    mobileDetails = findViewById(R.id.mobileDetails)
    wifiValue = findViewById(R.id.wifiValue)
    wifiDetails = findViewById(R.id.wifiDetails)
    pingValue = findViewById(R.id.pingValue)
    pingDetails = findViewById(R.id.pingDetails)
    statusLog = findViewById(R.id.statusLog)
    transLabel = findViewById(R.id.transLabel)
    transparency = findViewById(R.id.transparency)

    val parentView = mobileValue.getParent()

    panel = if (parentView is android.view.View) {
        parentView
    } else {
        findViewById(android.R.id.content)
    }
}


    private fun requestNeededPermissions() {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.READ_PHONE_STATE
        )
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 100)
    }

    private fun checkRoot() {
        Thread {
            rootAvailable = RootShell.isRootAvailable()
            runOnUiThread {
                rootStatus.text = if (rootAvailable) "HYBRID-ROOT • ROOT TERDETEKSI" else
                    "HYBRID-ROOT • Tanpa root (Hybrid mode)"
            }
        }.start()
    }

    
private fun setupCustomization() {
    val prefs = getSharedPreferences("studio", MODE_PRIVATE)

    val savedTransparency = prefs.getInt("trans", 68)
        .coerceIn(1, 100)

    transparency.max = 99
    transparency.progress = savedTransparency - 1

    fun applyTransparency(percent: Int) {
        transLabel.text = "Transparansi panel: $percent%"
        panel.background?.mutate()?.alpha = percent * 255 / 100
    }

    applyTransparency(savedTransparency)

    transparency.setOnSeekBarChangeListener(
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(
                seekBar: SeekBar?,
                progress: Int,
                fromUser: Boolean
            ) {
                val percent = progress + 1
                applyTransparency(percent)

                if (fromUser) {
                    prefs.edit().putInt("trans", percent).apply()
                }
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}

            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        }
    )

    val colors = listOf(
        "Cyber Cyan",
        "Neon Green",
        "Purple",
        "Orange",
        "White"
    )

    val spinner = findViewById<Spinner>(R.id.colorSpinner)

    spinner.adapter = ArrayAdapter(
        this,
        android.R.layout.simple_spinner_dropdown_item,
        colors
    )

    val savedColor = prefs.getInt(
        "accent",
        Color.rgb(0, 229, 255)
    )

    fun applyAccent(color: Int) {
        mobileValue.setTextColor(color)
        pingValue.setTextColor(color)
    }

    applyAccent(savedColor)

    spinner.onItemSelectedListener =
        object : android.widget.AdapterView.OnItemSelectedListener {

            override fun onNothingSelected(
                parent: android.widget.AdapterView<*>?
            ) {}

            override fun onItemSelected(
                parent: android.widget.AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                val color = when (position) {
                    1 -> Color.rgb(0, 255, 130)
                    2 -> Color.rgb(170, 90, 255)
                    3 -> Color.rgb(255, 170, 0)
                    4 -> Color.WHITE
                    else -> Color.rgb(0, 229, 255)
                }

                applyAccent(color)
                prefs.edit().putInt("accent", color).apply()
            }
        }
}


    private fun startMonitoring() {
        executor.scheduleAtFixedRate({
            readMobile()
            readWifi()
            runPing()
        }, 0, 2, TimeUnit.SECONDS)
    }

    @Suppress("DEPRECATION")
    private fun readMobile() {
        try {
            val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
            val operator = tm.networkOperatorName.ifBlank { "Operator tidak tersedia" }
            val type = when (tm.dataNetworkType) {
                TelephonyManager.NETWORK_TYPE_LTE -> "LTE / 4G"
                TelephonyManager.NETWORK_TYPE_NR -> "5G NR"
                TelephonyManager.NETWORK_TYPE_HSPA, TelephonyManager.NETWORK_TYPE_HSPAP -> "HSPA"
                TelephonyManager.NETWORK_TYPE_EDGE -> "EDGE"
                TelephonyManager.NETWORK_TYPE_GPRS -> "GPRS"
                TelephonyManager.NETWORK_TYPE_UMTS -> "UMTS / 3G"
                TelephonyManager.NETWORK_TYPE_GSM -> "GSM"
                else -> "Tipe jaringan tidak diketahui"
            }
            var dbmText = "Kekuatan sinyal: tidak tersedia"
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                val cells = tm.allCellInfo
                val cell = cells?.firstOrNull { it.isRegistered }
                if (cell != null) {
                    val dbm = when (cell) {
                        is CellInfoLte -> cell.cellSignalStrength.dbm
                        is CellInfoGsm -> cell.cellSignalStrength.dbm
                        is CellInfoWcdma -> cell.cellSignalStrength.dbm
                        is CellInfoCdma -> cell.cellSignalStrength.dbm
                        else -> Int.MAX_VALUE
                    }
                    if (dbm != Int.MAX_VALUE) dbmText = "Sinyal: $dbm dBm"
                }
            }
            runOnUiThread {
                mobileValue.text = dbmText
                mobileDetails.text = "$operator • $type"
            }
        } catch (e: Exception) {
            runOnUiThread { mobileValue.text = "Data seluler dibatasi sistem" }
        }
    }

    @Suppress("DEPRECATION")
    private fun readWifi() {
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            val info = wm.connectionInfo
            val connected = info != null && info.networkId != -1
            runOnUiThread {
                wifiValue.text = if (connected) "Wi-Fi terhubung • ${info.rssi} dBm" else "Wi-Fi tidak terhubung"
                wifiDetails.text = if (connected) "Link: ${info.linkSpeed} Mbps • IP: ${formatIp(info.ipAddress)}"
                    else "Tidak ada data Wi-Fi aktif"
            }
        } catch (e: Exception) {
            runOnUiThread { wifiValue.text = "Data Wi-Fi tidak tersedia" }
        }
    }

    private fun formatIp(ip: Int): String =
        "${ip and 0xff}.${ip shr 8 and 0xff}.${ip shr 16 and 0xff}.${ip shr 24 and 0xff}"

    private fun runPing() {
        val start = System.nanoTime()
        try {
            val reachable = InetAddress.getByName("1.1.1.1").isReachable(1200)
            val ms = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - start)
            if (reachable) {
                pingCount++
                pingTotal += ms
                pingMin = minOf(pingMin, ms)
                pingMax = maxOf(pingMax, ms)
                runOnUiThread {
                    pingValue.text = "$ms ms"
                    pingDetails.text = "1.1.1.1 • avg ${pingTotal / pingCount} ms • min $pingMin • max $pingMax"
                }
            } else {
                runOnUiThread { pingValue.text = "Timeout / ICMP dibatasi" }
            }
        } catch (e: Exception) {
            runOnUiThread { pingValue.text = "Ping gagal: koneksi tidak tersedia" }
        }
    }

    private fun toggleWifi() {
        if (rootAvailable) {
            val desired = !wifiOn
            val result = RootShell.run("svc wifi ${if (desired) "enable" else "disable"}")
            if (result) {
                wifiOn = desired
                log("Perintah Wi-Fi dikirim melalui root.")
            } else {
                startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                log("Root command gagal; membuka pengaturan Wi-Fi.")
            }
        } else {
            startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
            log("Android membatasi toggle langsung; silakan ubah dari pengaturan.")
        }
    }

    private fun toggleMobileData() {
        if (!rootAvailable) {
            startActivity(Intent(Settings.ACTION_WIRELESS_SETTINGS))
            log("Data seluler memerlukan root atau kontrol sistem.")
            return
        }
        val desired = !dataOn
        val ok = RootShell.run("svc data ${if (desired) "enable" else "disable"}")
        if (ok) {
            dataOn = desired
            log("Perintah data seluler dikirim. Status diverifikasi dari sistem.")
        } else {
            startActivity(Intent(Settings.ACTION_DATA_ROAMING_SETTINGS))
            log("Perintah data gagal; membuka pengaturan jaringan.")
        }
    }

    private fun log(message: String) {
        statusLog.text = "Log: $message"
    }

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
    }
}
