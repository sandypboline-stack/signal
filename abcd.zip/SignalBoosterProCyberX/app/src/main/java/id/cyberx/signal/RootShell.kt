package id.cyberx.signal

import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

/**
 * Runs only fixed, app-owned commands. Never pass arbitrary user text to this class.
 * Root access is optional; normal mode remains usable without it.
 */
object RootShell {
    fun isRootAvailable(): Boolean {
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val finished = process.waitFor(3, TimeUnit.SECONDS)
            finished && process.exitValue() == 0
        } catch (_: Exception) {
            false
        }
    }

    fun run(command: String): Boolean {
        val allowed = setOf(
            "svc wifi enable", "svc wifi disable",
            "svc data enable", "svc data disable"
        )
        if (command !in allowed) return false
        return try {
            val process = Runtime.getRuntime().exec(arrayOf("su", "-c", command))
            process.waitFor(5, TimeUnit.SECONDS) && process.exitValue() == 0
        } catch (_: Exception) {
            false
        }
    }
}
